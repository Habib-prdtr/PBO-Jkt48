<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Test Gambar</title>
</head>
<body>
    <img src="../coba2/images/event/1.png" alt="Test Foto" />
</body>
</html>
